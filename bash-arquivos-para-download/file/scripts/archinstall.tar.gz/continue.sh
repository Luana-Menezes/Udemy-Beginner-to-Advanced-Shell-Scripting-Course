#!/bin/bash
  echo -e "[13] - Configurando o horário para Brasil ..."
  ln -sf /usr/share/zoneinfo/Brazil/East /etc/localtime # hwclock --systohc

  echo -e "[14] - Gerando o idioma para Português Brasil ..."
  echo "pt_BR.UTF-8 UTF-8" >> /etc/locale.gen && locale-gen

  echo -e "[15] - Configurando o idioma para Português Brasil ..."
  echo "LANG=pt_BR.UTF-8" > /etc/locale.conf

  echo -e "[16] - Configurando o teclado para Português Brasil ..."
  echo "KEYMAP=br-abnt2" > /etc/vconsole.conf

  echo -e "[17] - Definindo o nome do computador para arch-linux ..."
  echo "arch-linux" > /etc/hostname

  echo -e "[18] - Definindo virtual host para localhost.localdomain e arch-linux ..."
  CONTEUDO_HOSTS="127.0.0.1\tlocalhost\n::1\tlocalhost\n127.0.1.1\tarch-linux.localdomain\tarch-linux\n"
  echo -e "$CONTEUDO_HOSTS" > /etc/hosts


  # OPCIONAL: # wifi-menu
  echo -e "[19] - Defina a senha de root e Copiando imagem do kernel..."
  passwd
  mkinitcpio -p linux

  echo -e "FASE 3: Aplicativos e usuários adicionais.\n"

  echo -e "[20] - Instalar Grub e configurações ..."
  pacman -S grub --noconfirm
  grub-install --target=i386-pc --recheck /dev/sda
  pacman -S os-prober --noconfirm && grub-mkconfig -o /boot/grub/grub.cfg

  echo -e "[21] - Saindo do chroot"
  exit
