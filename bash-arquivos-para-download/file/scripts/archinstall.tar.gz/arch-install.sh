#!/bin/bash
# Script para instalação do Arch Linux
clear
cat <<EOF

        ================================================
        Bem-vindo ao Terminal Root Installer Arch Linux!
        ================================================

        AVISO IMPORTANTE:
        ================
        
            Esse Instalador assume que você deseja instalar o Arch Linux
            em todo seu HD (Disco Rígido). E irá instalar, além da partição 
            'root' também uma partição de 'boot' e a 'swap'. Se não deseja essa 
            estrutura no seu HD ou se deseja manter possíveis sistemas, se exis-
            tirem,
            
            tecle: n
            
            Para sair do instalador para 
            utilizar outros modelos de instalação que é possível configurar as 
            partições do Disco Rígido (HD).
    
EOF

echo
echo -e "FASE 1: Preparando o Ambiente para receber o Arch Linux."
echo -ne "\nDeseja realmente iniciar a instalação ? [S/n]: "
read INSTALAR

if [[ "$INSTALAR" == "S" ]]; then

    echo -e "[00] - Iniciando a instalação ..."
    
    echo -e "[01] - Definindo a configuração do teclado para Português Brasil ..."
    loadkeys br-abnt2
    
    echo -e "[02] - Testando conexão com a internet\n
    e ajustando a hora ..."
    ping -c1 www.terminalroot.com.br
    timedatectl set-ntp true
    
    echo -e "[03] - Criando as partições ..."
    PART=$(fdisk -l | sed -n 1p | cut -d: -f2 | cut -d, -f1 | tr -d a-zA-Z" ")
    NOME=$(fdisk -l | sed -n 1p | grep '/dev/...' | sed 's/.*\/dev\///g' | sed 's/\:.*//g')
    RAIZ=$(( $PART - 2 ))
    (echo n; echo p; echo; echo; echo "+$RAIZ""G";echo w) | fdisk /dev/$NOME
    (echo n; echo p; echo; echo; echo "+2""M";echo w) | fdisk /dev/$NOME
    (echo n; echo p; echo; echo; echo; echo t; echo; echo 82; echo w) | fdisk /dev/$NOME
    
    echo -e "[04] - Formatando a partição / (raíz/root) como ext4 ..."
    mkfs.ext4 /dev/sda1

    echo -e "[05] - Formatando a swap ..."
    mkswap /dev/sda3
    
    echo -e "[06] - Ativando a swap ..."
    swapon /dev/sda3
    
    echo -e "[07] -Montando a partição root em /mnt ..."
    mount /dev/sda1 /mnt
    
    echo -e "[08] - Criando o diretório /mnt/boot ..."
    mkdir /mnt/boot
    
    echo -e "[09] - Montando a partição /dev/sda2 no diretório /mnt/boot ..."
    mount /dev/sda2 /mnt/boot
    
    echo -e "FASE 2: Instalação do Arch Linux.\n"
    
    echo -e "[10] - Instalando os pacotes básicos do Arch Linux ..."
    pacstrap /mnt base
    
    echo -e "[11] - Gerando a tabela dos sistemas de arquivos ..."
    genfstab -U /mnt >> /mnt/etc/fstab
    
    echo -e "[12] - Fazendo o chroot ..."
    mv continue.sh /mnt
    arch-chroot /mnt ./continue.sh

    echo -e "[22] - Desmontando /mnt"
    umount -R /mnt

    exit
    echo -e "[23] - FINAL DA INSTALAÇÃO."
    echo -e "Retire o cd/dvd de instalação e '# reboot' o sistema."

fi

